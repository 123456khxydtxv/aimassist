@echo off
call "%~dp0gradlew.bat" clean build
