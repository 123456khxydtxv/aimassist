# Aim Assist - Fabric 26.2

Standalone client-side recreation of the Aim Assist feature inspected from the user-provided client JAR.

## Build

Requirements:
- Minecraft Java 26.2
- Fabric Loader 0.19.3 or newer
- Fabric API 0.156.0+26.2
- Java 25
- Windows PowerShell/internet for the first Gradle bootstrap

### Windows

Open PowerShell in this folder and run:

```powershell
.\gradlew.bat clean build
```

The first run downloads Gradle 9.5.1 automatically into `.gradle-local` if it is not already present. The built JAR will be in `build\libs\`.

## Controls

- `R` toggles Aim Assist.
- By default, aiming only runs while the normal attack key is held.

## Configuration

The file `config/aimassist.properties` is created when the client starts. Settings mirror the inspected feature where practical:

- Range: 1.0-6.0, default 4.5
- Rotation Speed: 10-3600 degrees/second, default 600
- FOV: 30-360 degrees, default 120
- Aim At: AUTO, HEAD, CENTER, FEET
- Ignore Mouse Input: 0-100% (stored for compatibility; direct camera steering is used by this standalone implementation)
- Check Line Of Sight: true/false, default true
- Aim While Blocking: true/false, default false
- Player/hostile/passive/baby/invisible/named/armor-stand filters

## Notes

This project contains a clean-room standalone implementation rather than distributing the original client's compiled classes or private source. The behavior was recreated from the feature behavior and settings visible in the supplied JAR.


## Important Minecraft 26.2 build note

Minecraft 26.2 uses the unobfuscated official codebase. This project therefore uses
the `net.fabricmc.fabric-loom` 1.17.x plugin and does NOT declare
`loom.officialMojangMappings()`. Do not add a mappings dependency for 26.2.

Build from this folder with:

    .\gradlew.bat clean build

The installable jar is produced in `build/libs/` and is the regular `.jar` output,
not a `-dev` jar.


## Automatic targeting
When Aim Assist is ON, it does not require the attack button. It automatically selects the nearest valid target inside the configured range and FOV and rotates toward the configured aim point. Blocking does not disable aiming.
