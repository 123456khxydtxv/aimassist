package com.aimassist.client;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Simple translucent settings screen for Aim Assist. */
public final class AimAssistScreen extends Screen {
    private final Screen parent;

    public AimAssistScreen(Screen parent) {
        super(Component.literal("Aim Assist"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        AimAssistConfig c = AimAssistClient.config();
        int panelW = 300;
        int left = (this.width - panelW) / 2;
        int y = Math.max(24, (this.height - 260) / 2);
        int row = 24;

        this.addRenderableWidget(button(left, y, panelW, () -> {
            AimAssistClient.setEnabled(this.minecraft, !AimAssistClient.enabled);
            rebuild();
        }, "Aim Assist: " + (AimAssistClient.enabled ? "ON" : "OFF")));
        y += row;

        this.addRenderableWidget(button(left, y, 145, () -> { c.range = Math.max(1.0, c.range - 0.5); save(); rebuild(); }, "Range -  " + fmt(c.range)));
        this.addRenderableWidget(button(left + 155, y, 145, () -> { c.range = Math.min(6.0, c.range + 0.5); save(); rebuild(); }, "Range +  " + fmt(c.range)));
        y += row;

        this.addRenderableWidget(button(left, y, 145, () -> { c.fov = Math.max(30.0, c.fov - 10.0); save(); rebuild(); }, "FOV -  " + fmt0(c.fov) + "°"));
        this.addRenderableWidget(button(left + 155, y, 145, () -> { c.fov = Math.min(360.0, c.fov + 10.0); save(); rebuild(); }, "FOV +  " + fmt0(c.fov) + "°"));
        y += row;

        this.addRenderableWidget(button(left, y, 145, () -> { c.rotationSpeed = Math.max(10.0, c.rotationSpeed - 100.0); save(); rebuild(); }, "Speed -  " + fmt0(c.rotationSpeed)));
        this.addRenderableWidget(button(left + 155, y, 145, () -> { c.rotationSpeed = Math.min(3600.0, c.rotationSpeed + 100.0); save(); rebuild(); }, "Speed +  " + fmt0(c.rotationSpeed)));
        y += row;

        this.addRenderableWidget(button(left, y, panelW, () -> {
            c.aimAt = switch (c.aimAt) {
                case HEAD -> AimAssistConfig.AimAt.CENTER;
                case CENTER -> AimAssistConfig.AimAt.FEET;
                case FEET -> AimAssistConfig.AimAt.AUTO;
                case AUTO -> AimAssistConfig.AimAt.HEAD;
            };
            save(); rebuild();
        }, "Aim At: " + c.aimAt));
        y += row;

        this.addRenderableWidget(button(left, y, 145, () -> { c.checkLineOfSight = !c.checkLineOfSight; save(); rebuild(); }, "Line of Sight: " + onOff(c.checkLineOfSight)));
        this.addRenderableWidget(button(left + 155, y, 145, () -> { c.aimWhileBlocking = !c.aimWhileBlocking; save(); rebuild(); }, "While Blocking: " + onOff(c.aimWhileBlocking)));
        y += row;

        this.addRenderableWidget(button(left, y, 145, () -> { c.requireAttackKey = !c.requireAttackKey; save(); rebuild(); }, "Attack Key: " + onOff(c.requireAttackKey)));
        this.addRenderableWidget(button(left + 155, y, 145, () -> { c.players = !c.players; save(); rebuild(); }, "Players: " + onOff(c.players)));
        y += row;

        this.addRenderableWidget(button(left, y, 145, () -> { c.hostiles = !c.hostiles; save(); rebuild(); }, "Hostiles: " + onOff(c.hostiles)));
        this.addRenderableWidget(button(left + 155, y, 145, () -> { c.passive = !c.passive; save(); rebuild(); }, "Passive: " + onOff(c.passive)));
        y += row;

        this.addRenderableWidget(button(left, y, 145, () -> { c.invisible = !c.invisible; save(); rebuild(); }, "Invisible: " + onOff(c.invisible)));
        this.addRenderableWidget(button(left + 155, y, 145, () -> { c.babies = !c.babies; save(); rebuild(); }, "Babies: " + onOff(c.babies)));
        y += row;

        this.addRenderableWidget(button(left, y, panelW, b -> this.onClose(), "Close"));
    }

    private Button button(int x, int y, int width, Runnable action, String text) {
        return Button.builder(Component.literal(text), b -> action.run()).bounds(x, y, width, 20).build();
    }

    private void rebuild() {
        this.clearWidgets();
        this.init();
    }

    private static void save() {
        AimAssistClient.config().clamp();
        AimAssistClient.saveConfig();
    }

    private static String onOff(boolean v) { return v ? "ON" : "OFF"; }
    private static String fmt(double v) { return String.format(java.util.Locale.ROOT, "%.1f", v); }
    private static String fmt0(double v) { return String.format(java.util.Locale.ROOT, "%.0f", v); }

    @Override
    public void onClose() {
        this.minecraft.gui.setScreen(this.parent);
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
        super.extractRenderState(graphics, mouseX, mouseY, delta);
        int panelW = 320;
        int panelH = Math.min(300, this.height - 12);
        int left = (this.width - panelW) / 2;
        int top = (this.height - panelH) / 2;
        graphics.fill(left, top, left + panelW, top + panelH, 0xAA0B0F16);
        graphics.text(this.font, "Aim Assist Settings", left + 10, top + 8, 0xFFFFFFFF, true);
        graphics.text(this.font, "Press O to open • R to toggle", left + 10, top + 20, 0xFFB8C2D1, false);
    }
}
