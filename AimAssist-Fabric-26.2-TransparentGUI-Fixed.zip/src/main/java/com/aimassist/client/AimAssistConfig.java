package com.aimassist.client;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;
import java.util.Properties;

public final class AimAssistConfig {
    public double range = 4.5;
    public double rotationSpeed = 600.0;
    public double fov = 120.0;
    public AimAt aimAt = AimAt.HEAD;
    public double ignoreMouseInput = 0.0;
    public boolean checkLineOfSight = true;
    public boolean aimWhileBlocking = true;

    public boolean players = true;
    public boolean hostiles = true;
    public boolean passive = true;
    public boolean babies = true;
    public boolean invisible = true;
    public boolean named = false;
    public boolean armorStands = true;
    public boolean crystals = true;

    public boolean requireAttackKey = false;

    public enum AimAt { AUTO, HEAD, CENTER, FEET }

    public void clamp() {
        range = Math.max(1.0, Math.min(6.0, range));
        rotationSpeed = Math.max(10.0, Math.min(3600.0, rotationSpeed));
        fov = Math.max(30.0, Math.min(360.0, fov));
        ignoreMouseInput = Math.max(0.0, Math.min(1.0, ignoreMouseInput));
        if (aimAt == null) aimAt = AimAt.AUTO;
    }

    public void load(Path path) {
        try {
            if (!Files.exists(path)) {
                save(path);
                return;
            }
            Properties p = new Properties();
            try (var reader = Files.newBufferedReader(path)) { p.load(reader); }
            range = parse(p, "range", range);
            rotationSpeed = parse(p, "rotationSpeed", rotationSpeed);
            fov = parse(p, "fov", fov);
            ignoreMouseInput = parse(p, "ignoreMouseInput", ignoreMouseInput);
            aimAt = parseEnum(p, "aimAt", aimAt);
            checkLineOfSight = Boolean.parseBoolean(p.getProperty("checkLineOfSight", Boolean.toString(checkLineOfSight)));
            aimWhileBlocking = Boolean.parseBoolean(p.getProperty("aimWhileBlocking", Boolean.toString(aimWhileBlocking)));
            players = bool(p, "players", players);
            hostiles = bool(p, "hostiles", hostiles);
            passive = bool(p, "passive", passive);
            babies = bool(p, "babies", babies);
            invisible = bool(p, "invisible", invisible);
            named = bool(p, "named", named);
            armorStands = bool(p, "armorStands", armorStands);
            crystals = bool(p, "crystals", crystals);
            requireAttackKey = bool(p, "requireAttackKey", requireAttackKey);
            clamp();
        } catch (Exception ignored) {
            clamp();
        }
    }

    public void save(Path path) {
        clamp();
        try {
            Files.createDirectories(path.getParent());
            Properties p = new Properties();
            p.setProperty("range", Double.toString(range));
            p.setProperty("rotationSpeed", Double.toString(rotationSpeed));
            p.setProperty("fov", Double.toString(fov));
            p.setProperty("aimAt", aimAt.name());
            p.setProperty("ignoreMouseInput", Double.toString(ignoreMouseInput));
            p.setProperty("checkLineOfSight", Boolean.toString(checkLineOfSight));
            p.setProperty("aimWhileBlocking", Boolean.toString(aimWhileBlocking));
            p.setProperty("players", Boolean.toString(players));
            p.setProperty("hostiles", Boolean.toString(hostiles));
            p.setProperty("passive", Boolean.toString(passive));
            p.setProperty("babies", Boolean.toString(babies));
            p.setProperty("invisible", Boolean.toString(invisible));
            p.setProperty("named", Boolean.toString(named));
            p.setProperty("armorStands", Boolean.toString(armorStands));
            p.setProperty("crystals", Boolean.toString(crystals));
            p.setProperty("requireAttackKey", Boolean.toString(requireAttackKey));
            try (var writer = Files.newBufferedWriter(path)) { p.store(writer, "Aim Assist configuration"); }
        } catch (IOException ignored) { }
    }

    private static double parse(Properties p, String key, double fallback) {
        try { return Double.parseDouble(p.getProperty(key, Double.toString(fallback))); }
        catch (NumberFormatException e) { return fallback; }
    }
    private static boolean bool(Properties p, String key, boolean fallback) {
        return Boolean.parseBoolean(p.getProperty(key, Boolean.toString(fallback)));
    }
    private static AimAt parseEnum(Properties p, String key, AimAt fallback) {
        try { return AimAt.valueOf(p.getProperty(key, fallback.name()).toUpperCase(Locale.ROOT)); }
        catch (IllegalArgumentException e) { return fallback; }
    }
}
