package com.aimassist.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.minecraft.client.KeyMapping;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.ambient.AmbientCreature;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraft.util.Mth;

import java.nio.file.Path;
import java.util.Comparator;
import java.util.List;

public final class AimAssistClient implements ClientModInitializer {
    private static final AimAssistConfig CONFIG = new AimAssistConfig();
    public static boolean enabled = false;
    private static Entity target;
    private static final KeyMapping TOGGLE = new KeyMapping(
            "key.aimassist.toggle",
            InputConstants.Type.KEYSYM,
            InputConstants.KEY_R,
            KeyMapping.Category.MISC
    );
    private static final KeyMapping RANGE_DOWN = key("key.aimassist.range_down", InputConstants.KEY_F6);
    private static final KeyMapping RANGE_UP = key("key.aimassist.range_up", InputConstants.KEY_F7);
    private static final KeyMapping FOV_DOWN = key("key.aimassist.fov_down", InputConstants.KEY_F8);
    private static final KeyMapping FOV_UP = key("key.aimassist.fov_up", InputConstants.KEY_F9);
    private static final KeyMapping SPEED_DOWN = key("key.aimassist.speed_down", InputConstants.KEY_F10);
    private static final KeyMapping SPEED_UP = key("key.aimassist.speed_up", InputConstants.KEY_F11);
    private static final KeyMapping OPEN_GUI = key("key.aimassist.open_gui", InputConstants.KEY_O);

    private static KeyMapping key(String translationKey, int keyCode) {
        return new KeyMapping(translationKey, InputConstants.Type.KEYSYM, keyCode, KeyMapping.Category.MISC);
    }

    @Override
    public void onInitializeClient() {
        Path configPath = Path.of("config", "aimassist.properties");
        CONFIG.load(configPath);
        KeyMappingHelper.registerKeyMapping(TOGGLE);
        KeyMappingHelper.registerKeyMapping(RANGE_DOWN);
        KeyMappingHelper.registerKeyMapping(RANGE_UP);
        KeyMappingHelper.registerKeyMapping(FOV_DOWN);
        KeyMappingHelper.registerKeyMapping(FOV_UP);
        KeyMappingHelper.registerKeyMapping(SPEED_DOWN);
        KeyMappingHelper.registerKeyMapping(SPEED_UP);
        KeyMappingHelper.registerKeyMapping(OPEN_GUI);

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (TOGGLE.consumeClick()) toggle(client);
            while (RANGE_DOWN.consumeClick()) changeRange(client, -0.5);
            while (RANGE_UP.consumeClick()) changeRange(client, 0.5);
            while (FOV_DOWN.consumeClick()) changeFov(client, -10.0);
            while (FOV_UP.consumeClick()) changeFov(client, 10.0);
            while (SPEED_DOWN.consumeClick()) changeSpeed(client, -100.0);
            while (SPEED_UP.consumeClick()) changeSpeed(client, 100.0);
            while (OPEN_GUI.consumeClick()) client.gui.setScreen(new AimAssistScreen(client.gui.screen()));
            if (enabled) tick(client);
        });
    }

    public static AimAssistConfig config() { return CONFIG; }

    public static void setEnabled(Minecraft client, boolean value) {
        enabled = value;
        target = null;
        if (client.player != null) {
            client.gui.hud.setOverlayMessage(Component.literal("Aim Assist: " + (enabled ? "ON" : "OFF")), false);
        }
    }

    public static void saveConfig() {
        CONFIG.save(Path.of("config", "aimassist.properties"));
    }

    private static void toggle(Minecraft client) {
        enabled = !enabled;
        target = null;
        if (client.player != null) {
            client.gui.hud.setOverlayMessage(
                    Component.literal("Aim Assist: " + (enabled ? "ON" : "OFF")), false);
        }
    }

    private static void changeRange(Minecraft client, double amount) {
        CONFIG.range += amount;
        CONFIG.clamp();
        CONFIG.save(Path.of("config", "aimassist.properties"));
        showSetting(client, "Range", String.format(java.util.Locale.ROOT, "%.1f", CONFIG.range));
    }

    private static void changeFov(Minecraft client, double amount) {
        CONFIG.fov += amount;
        CONFIG.clamp();
        CONFIG.save(Path.of("config", "aimassist.properties"));
        showSetting(client, "FOV", String.format(java.util.Locale.ROOT, "%.0f", CONFIG.fov));
    }

    private static void changeSpeed(Minecraft client, double amount) {
        CONFIG.rotationSpeed += amount;
        CONFIG.clamp();
        CONFIG.save(Path.of("config", "aimassist.properties"));
        showSetting(client, "Rotation Speed", String.format(java.util.Locale.ROOT, "%.0f", CONFIG.rotationSpeed));
    }

    private static void showSetting(Minecraft client, String name, String value) {
        if (client.player != null) {
            client.gui.hud.setOverlayMessage(Component.literal(name + ": " + value), false);
        }
    }

    private static void tick(Minecraft client) {
        LocalPlayer player = client.player;
        if (player == null || client.level == null || client.gui.screen() != null) {
            target = null;
            return;
        }
        if (!CONFIG.aimWhileBlocking && player.isUsingItem()) {
            target = null;
            return;
        }
        if (CONFIG.requireAttackKey && !client.options.keyAttack.isDown()) {
            target = null;
            return;
        }

        double range = CONFIG.range;
        AABB search = player.getBoundingBox().inflate(range);
        List<Entity> candidates = client.level.getEntities(player, search, e -> isValidTarget(player, e));
        double halfFov = CONFIG.fov / 2.0;
        target = candidates.stream()
                .filter(e -> angleTo(player, aimPoint(e)) <= halfFov)
                .min(Comparator.comparingDouble(player::distanceToSqr))
                .orElse(null);

        if (target == null) return;
        Vec3 point = aimPoint(target);
        if (CONFIG.checkLineOfSight && !hasLineOfSight(player, point)) {
            target = null;
            return;
        }

        Rotation desired = rotationsTo(player.getEyePosition(1.0F), point);
        double maxStep = CONFIG.rotationSpeed / 20.0;
        float newYaw = stepAngle(player.getYRot(), desired.yaw, maxStep);
        float newPitch = stepAngle(player.getXRot(), desired.pitch, maxStep);
        player.setYRot(newYaw);
        player.setXRot(Mth.clamp(newPitch, -90.0F, 90.0F));
        player.setYHeadRot(newYaw);
    }

    private static boolean isValidTarget(Player player, Entity e) {
        if (e == player || !e.isAlive()) return false;
        if (!(e instanceof LivingEntity) && !(e instanceof ArmorStand)) return false;
        if (e instanceof Player && !CONFIG.players) return false;
        if (e instanceof ArmorStand && !CONFIG.armorStands) return false;
        if (e instanceof LivingEntity living) {
            if (!CONFIG.invisible && living.isInvisible()) return false;
            if (!CONFIG.named && living.hasCustomName()) return false;
            if (living instanceof AgeableMob ageable && ageable.isBaby() && !CONFIG.babies) return false;
            boolean hostile = e instanceof Monster;
            boolean passive = e instanceof Animal || e instanceof AmbientCreature;
            if (hostile && !CONFIG.hostiles) return false;
            if (passive && !CONFIG.passive && !(e instanceof Player)) return false;
            if (!hostile && !passive && !(e instanceof Player) && !CONFIG.passive) return false;
        }
        return player.distanceToSqr(e) <= CONFIG.range * CONFIG.range;
    }

    private static Vec3 aimPoint(Entity e) {
        AABB b = e.getBoundingBox();
        double x = (b.minX + b.maxX) * 0.5;
        double z = (b.minZ + b.maxZ) * 0.5;
        return switch (CONFIG.aimAt) {
            case HEAD -> new Vec3(x, b.maxY - Math.min(0.15, e.getBbHeight() * 0.08), z);
            case FEET -> new Vec3(x, b.minY + Math.min(0.1, e.getBbHeight() * 0.05), z);
            case CENTER -> new Vec3(x, (b.minY + b.maxY) * 0.5, z);
            case AUTO -> new Vec3(x, b.minY + e.getBbHeight() * 0.75, z);
        };
    }

    private static boolean hasLineOfSight(LocalPlayer player, Vec3 point) {
        var hit = player.level().clip(new net.minecraft.world.level.ClipContext(
                player.getEyePosition(1.0F), point,
                net.minecraft.world.level.ClipContext.Block.COLLIDER,
                net.minecraft.world.level.ClipContext.Fluid.NONE,
                player));
        return hit.getType() == net.minecraft.world.phys.HitResult.Type.MISS;
    }

    private static double angleTo(Player player, Vec3 point) {
        Rotation r = rotationsTo(player.getEyePosition(1.0F), point);
        double dy = Math.abs(Mth.wrapDegrees(r.yaw - player.getYRot()));
        double dp = Math.abs(r.pitch - player.getXRot());
        return Math.sqrt(dy * dy + dp * dp);
    }

    private static Rotation rotationsTo(Vec3 from, Vec3 to) {
        double dx = to.x - from.x;
        double dy = to.y - from.y;
        double dz = to.z - from.z;
        double horizontal = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float)(Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float)(-Math.toDegrees(Math.atan2(dy, horizontal)));
        return new Rotation(yaw, pitch);
    }

    private static float stepAngle(float current, float target, double maxStep) {
        float delta = Mth.wrapDegrees(target - current);
        if (Math.abs(delta) <= maxStep) return target;
        return current + (float)(Math.copySign(maxStep, delta));
    }

    private record Rotation(float yaw, float pitch) {}
}
