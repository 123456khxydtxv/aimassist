@echo off
setlocal EnableExtensions EnableDelayedExpansion

set "ROOT=%~dp0"
set "GRADLE_VERSION=9.5.1"
set "DIST_DIR=%ROOT%.gradle-local\gradle-%GRADLE_VERSION%"
set "ZIP=%ROOT%.gradle-local\gradle-%GRADLE_VERSION%-bin.zip"

if not exist "%DIST_DIR%\bin\gradle.bat" (
  if not exist "%ROOT%.gradle-local" mkdir "%ROOT%.gradle-local"
  echo Gradle %GRADLE_VERSION% is not installed locally. Downloading...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%ZIP%'"
  if errorlevel 1 (
    echo Failed to download Gradle. Check your internet connection.
    exit /b 1
  )
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -LiteralPath '%ZIP%' -DestinationPath '%ROOT%.gradle-local' -Force"
  if errorlevel 1 (
    echo Failed to extract Gradle.
    exit /b 1
  )
)

call "%DIST_DIR%\bin\gradle.bat" %*
exit /b %ERRORLEVEL%
